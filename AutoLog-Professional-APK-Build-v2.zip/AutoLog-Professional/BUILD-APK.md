# ساخت APK برای AutoLog

این پروژه یک workflow آماده GitHub Actions دارد که APK اندروید را خودکار می‌سازد.

## روش پیشنهادی

1. این پوشه را در یک repository در GitHub آپلود کنید.
2. وارد تب **Actions** شوید.
3. workflow با نام **Build AutoLog APK** را باز کنید.
4. گزینه **Run workflow** را بزنید.
5. بعد از پایان build، در صفحه همان اجرای workflow بخش **Artifacts** را باز کنید.
6. فایل `AutoLog-debug-apk.zip` را دانلود و از حالت ZIP خارج کنید.
7. فایل `app-debug.apk` را روی گوشی نصب کنید.

## ساخت خودکار با Push

اگر repository روی شاخه `main` یا `master` push شود، workflow نیز اجرا می‌شود.

## نکته

این نسخه Debug APK است و برای نصب و تست روی گوشی مناسب است. برای انتشار در Google Play باید نسخه Release با کلید امضای اختصاصی ساخته شود.
