# Build AutoLog APK

The GitHub Actions workflow is included at `.github/workflows/build-apk.yml`.

Upload the **contents of this folder** to the root of a GitHub repository (not the ZIP itself).
Then open **Actions → Build AutoLog APK → Run workflow**. After success, download the **AutoLog-APK** artifact.
