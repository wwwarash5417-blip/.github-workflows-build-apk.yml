# Build AutoLog APK

This project includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.

1. Upload the contents of this folder to the root of a GitHub repository (not the ZIP itself).
2. Open **Actions**.
3. Select **Build AutoLog APK**.
4. Click **Run workflow**.
5. After the run succeeds, open the run and download the **AutoLog-APK** artifact.
