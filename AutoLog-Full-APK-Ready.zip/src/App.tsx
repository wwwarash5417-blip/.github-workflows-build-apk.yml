import { FormEvent, ReactNode, useEffect, useMemo, useState } from 'react';
import {
  BellRing, Car, CheckCircle2, ChevronDown, Download, FileText, Gauge,
  Info, Moon, Pencil, Plus, Search, Settings, Sun, Trash2, Wrench, X
} from 'lucide-react';

type Language = 'fa' | 'en';
type Theme = 'light' | 'dark';
type Tab = 'dashboard' | 'cars' | 'history' | 'settings';
type Category = 'oil' | 'tires' | 'brakes' | 'insurance' | 'inspection' | 'repair' | 'custom';

type CarInfo = {
  id: string; make: string; model: string; year: number; mileage: number;
  plate: string; fuel: string;
};

type Service = {
  id: string; carId: string; category: Category; title: string; date: string;
  mileage: number; cost: number; shop: string; notes: string;
};

type Reminder = {
  id: string; carId: string; title: string; dueMileage?: number;
  dueDate?: string; interval: number;
};

const categories: Record<Category, { fa: string; en: string; color: string }> = {
  oil: { fa: 'روغن و فیلتر', en: 'Oil & filters', color: 'bg-sky-50 text-sky-700 dark:bg-sky-950/60 dark:text-sky-300' },
  tires: { fa: 'لاستیک', en: 'Tires', color: 'bg-violet-50 text-violet-700 dark:bg-violet-950/60 dark:text-violet-300' },
  brakes: { fa: 'ترمز', en: 'Brakes', color: 'bg-rose-50 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300' },
  insurance: { fa: 'بیمه', en: 'Insurance', color: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300' },
  inspection: { fa: 'معاینه فنی', en: 'Inspection', color: 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300' },
  repair: { fa: 'تعمیرات', en: 'Repairs', color: 'bg-orange-50 text-orange-700 dark:bg-orange-950/60 dark:text-orange-300' },
  custom: { fa: 'سایر', en: 'Custom', color: 'bg-slate-100 text-slate-700 dark:bg-slate-700 dark:text-slate-200' },
};

const initialCars: CarInfo[] = [
  { id: 'car-1', make: 'Toyota', model: 'Corolla', year: 1400, mileage: 46800, plate: '24|ب|582|11', fuel: 'بنزین' }
];

const initialServices: Service[] = [
  { id: 'srv-1', carId: 'car-1', category: 'oil', title: 'تعویض روغن و فیلتر', date: '1404-08-21', mileage: 42800, cost: 1850000, shop: 'اتو سرویس مرکزی', notes: 'روغن 5W-30 و فیلتر اصلی' },
  { id: 'srv-2', carId: 'car-1', category: 'insurance', title: 'تمدید بیمه شخص ثالث', date: '1403-12-29', mileage: 39400, cost: 8900000, shop: 'بیمه ایران', notes: 'اعتبار یک‌ساله' },
];

const initialReminders: Reminder[] = [
  { id: 'rem-1', carId: 'car-1', title: 'تعویض روغن', dueMileage: 47800, interval: 5000 }
];

const load = <T,>(key: string, fallback: T): T => {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) as T : fallback;
  } catch { return fallback; }
};

const normalize = (value: string) =>
  value.replace(/[۰-۹]/g, d => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(d)))
       .replace(/[٠-٩]/g, d => String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));

const n = (value: number, language: Language) =>
  new Intl.NumberFormat(language === 'fa' ? 'fa-IR' : 'en-US').format(value);

/* Jalali conversion */
function gregorianToJalali(gy: number, gm: number, gd: number) {
  const gdm = [0,31,59,90,120,151,181,212,243,273,304,334];
  let jy = gy <= 1600 ? 0 : 979;
  gy -= gy <= 1600 ? 621 : 1600;
  const gy2 = gm > 2 ? gy + 1 : gy;
  let days = 365 * gy + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100)
    + Math.floor((gy2 + 399) / 400) - 80 + gd + gdm[gm - 1];
  jy += 33 * Math.floor(days / 12053);
  days %= 12053;
  jy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days > 365) {
    jy += Math.floor((days - 1) / 365);
    days = (days - 1) % 365;
  }
  const jm = days < 186 ? 1 + Math.floor(days / 31) : 7 + Math.floor((days - 186) / 30);
  const jd = 1 + (days < 186 ? days % 31 : (days - 186) % 30);
  return { jy, jm, jd };
}

function jalaliToGregorian(jy: number, jm: number, jd: number) {
  jy -= 979;
  let days = 365 * jy + Math.floor(jy / 33) * 8
    + Math.floor(((jy % 33) + 3) / 4) + 78 + jd
    + (jm < 7 ? (jm - 1) * 31 : (jm - 7) * 30 + 186);
  let gy = 1600 + 400 * Math.floor(days / 146097);
  days %= 146097;
  let leap = true;
  if (days >= 36525) {
    days--;
    gy += 100 * Math.floor(days / 36524);
    days %= 36524;
    if (days >= 365) days++; else leap = false;
  }
  gy += 4 * Math.floor(days / 1461);
  days %= 1461;
  if (days >= 366) {
    leap = false;
    days--;
    gy += Math.floor(days / 365);
    days %= 365;
  }
  const months = [31, leap ? 29 : 28, 31,30,31,30,31,31,30,31,30,31];
  let gm = 0;
  while (days >= months[gm]) days -= months[gm++];
  return { gy, gm: gm + 1, gd: days + 1 };
}

function jalaliToday() {
  const d = new Date();
  const j = gregorianToJalali(d.getFullYear(), d.getMonth() + 1, d.getDate());
  return `${j.jy}-${String(j.jm).padStart(2, '0')}-${String(j.jd).padStart(2, '0')}`;
}

function currentJalaliYear() {
  const d = new Date();
  return gregorianToJalali(d.getFullYear(), d.getMonth() + 1, d.getDate()).jy;
}

const jalaliMonths = [
  'فروردین','اردیبهشت','خرداد','تیر','مرداد','شهریور',
  'مهر','آبان','آذر','دی','بهمن','اسفند'
];

function isJalaliLeapYear(year: number) {
  const g = jalaliToGregorian(year, 12, 30);
  return gregorianToJalali(g.gy, g.gm, g.gd).jy === year;
}

function jalaliMonthDays(year: number, month: number) {
  if (month <= 6) return 31;
  if (month <= 11) return 30;
  return isJalaliLeapYear(year) ? 30 : 29;
}

function jalaliDate(value: string, language: Language) {
  const [y, m, d] = value.split('-').map(Number);
  if (!y || !m || !d) return value;
  if (language === 'fa') return `${n(d, 'fa')} ${jalaliMonths[m - 1]} ${n(y, 'fa')}`;
  const g = jalaliToGregorian(y, m, d);
  return new Intl.DateTimeFormat('en-US', { year: 'numeric', month: 'short', day: 'numeric' })
    .format(new Date(g.gy, g.gm - 1, g.gd));
}

function dateScore(value?: string) {
  if (!value) return Number.MAX_SAFE_INTEGER;
  const [y, m, d] = value.split('-').map(Number);
  const g = jalaliToGregorian(y, m, d);
  return new Date(g.gy, g.gm - 1, g.gd).getTime();
}

/* Plate is stored as four logical fields: two digits | letter | three digits | province code */
function normalizePlate(value: string) {
  const parts = value.includes('|') ? value.split('|') : value.split(/\s+/);
  return [
    normalize(parts[0] || '').replace(/\D/g, '').slice(0, 2),
    (parts[1] || '').slice(0, 1),
    normalize(parts[2] || '').replace(/\D/g, '').slice(0, 3),
    normalize(parts[parts.length - 1] || '').replace(/\D/g, '').slice(0, 2)
  ].join('|');
}

function plateParts(value: string) {
  const p = normalizePlate(value).split('|');
  return { first: p[0], letter: p[1], three: p[2], province: p[3] };
}

export default function App() {
  const [language, setLanguage] = useState<Language>(() => load('autolog-lang', 'fa'));
  const [theme, setTheme] = useState<Theme>(() => load('autolog-theme', 'light'));
  const [cars, setCars] = useState<CarInfo[]>(() =>
    load('autolog-cars', initialCars).map(car =>
      ({ ...car, plate: normalizePlate(car.plate), year: car.year > 1700 ? gregorianToJalali(car.year, 7, 1).jy : car.year })
    )
  );
  const [services, setServices] = useState<Service[]>(() => load('autolog-services', initialServices));
  const [reminders, setReminders] = useState<Reminder[]>(() => load('autolog-reminders', initialReminders));
  const [carId, setCarId] = useState(() => load('autolog-current-car', 'car-1'));
  const [tab, setTab] = useState<Tab>('dashboard');
  const [menu, setMenu] = useState(false);
  const [carForm, setCarForm] = useState(false);
  const [serviceForm, setServiceForm] = useState(false);
  const [editing, setEditing] = useState<Service | null>(null);
  const [notice, setNotice] = useState('');

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
    localStorage.setItem('autolog-theme', JSON.stringify(theme));
  }, [theme]);

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'fa' ? 'rtl' : 'ltr';
    localStorage.setItem('autolog-lang', JSON.stringify(language));
  }, [language]);

  useEffect(() => {
    localStorage.setItem('autolog-cars', JSON.stringify(cars));
    localStorage.setItem('autolog-services', JSON.stringify(services));
    localStorage.setItem('autolog-reminders', JSON.stringify(reminders));
    localStorage.setItem('autolog-current-car', JSON.stringify(carId));
  }, [cars, services, reminders, carId]);

  const t = (fa: string, en: string) => language === 'fa' ? fa : en;
  const car = cars.find(c => c.id === carId);

  const records = useMemo(
    () => services.filter(s => s.carId === carId).sort((a, b) => dateScore(b.date) - dateScore(a.date)),
    [services, carId]
  );

  const addCar = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const f = new FormData(e.currentTarget);
    const added: CarInfo = {
      id: crypto.randomUUID(),
      make: String(f.get('make')).trim(),
      model: String(f.get('model')).trim(),
      year: Number(normalize(String(f.get('year')))),
      mileage: Number(normalize(String(f.get('mileage')))),
      plate: normalizePlate(String(f.get('plate'))),
      fuel: String(f.get('fuel')).trim()
    };
    setCars(v => [...v, added]);
    setCarId(added.id);
    setCarForm(false);
    setNotice(t('خودرو اضافه شد.', 'Vehicle added.'));
  };

  const saveService = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!car) return;
    const f = new FormData(e.currentTarget);
    const category = String(f.get('category')) as Category;
    const rawDate = normalize(String(f.get('date')));
    const entry: Service = {
      id: editing?.id ?? crypto.randomUUID(),
      carId: car.id,
      category,
      title: String(f.get('title')).trim() || categories[category][language],
      date: rawDate,
      mileage: Number(normalize(String(f.get('mileage')))),
      cost: Number(normalize(String(f.get('cost')))),
      shop: String(f.get('shop')).trim(),
      notes: String(f.get('notes')).trim()
    };
    setServices(v => editing ? v.map(s => s.id === entry.id ? entry : s) : [entry, ...v]);
    setCars(v => v.map(c => c.id === car.id ? { ...c, mileage: Math.max(c.mileage, entry.mileage) } : c));
    setEditing(null);
    setServiceForm(false);
    setNotice(t('سرویس ذخیره شد.', 'Service saved.'));
  };

  const deleteCar = (id: string) => {
    const item = cars.find(c => c.id === id);
    if (!item) return;
    const ok = window.confirm(t(
      `خودرو «${item.make} ${item.model}» و تمام سوابق و یادآورهای آن حذف شود؟`,
      `Delete ${item.make} ${item.model} and all its records and reminders?`
    ));
    if (!ok) return;
    const rest = cars.filter(c => c.id !== id);
    setCars(rest);
    setServices(v => v.filter(s => s.carId !== id));
    setReminders(v => v.filter(r => r.carId !== id));
    setCarId(rest[0]?.id ?? '');
    setTab(rest.length ? 'dashboard' : 'cars');
    setNotice(t('خودرو و تمام سوابق آن حذف شد.', 'Vehicle and all related records were deleted.'));
  };

  const deleteService = (id: string) => {
    if (!window.confirm(t('این سرویس حذف شود؟', 'Delete this service?'))) return;
    setServices(v => v.filter(s => s.id !== id));
    setNotice(t('سرویس حذف شد.', 'Service deleted.'));
  };

  const backup = () => {
    const blob = new Blob([JSON.stringify({ cars, services, reminders }, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'autolog-backup.json';
    a.click();
    URL.revokeObjectURL(a.href);
  };

  return (
    <main className="min-h-screen bg-[#f5f7fb] text-slate-900 dark:bg-[#0b1220] dark:text-slate-100">
      <div className="mx-auto min-h-screen w-full max-w-6xl px-4 pb-28 pt-5 sm:px-6 lg:px-8">
        <Header t={t} car={car} cars={cars} menu={menu} onMenu={() => setMenu(!menu)}
          onSelect={id => { setCarId(id); setMenu(false); }} onAdd={() => { setMenu(false); setCarForm(true); }}
          language={language} theme={theme} onLanguage={() => setLanguage(language === 'fa' ? 'en' : 'fa')}
          onTheme={() => setTheme(theme === 'light' ? 'dark' : 'light')} />

        {notice && <Notice text={notice} onClose={() => setNotice('')} />}

        {tab === 'dashboard' && <Dashboard t={t} language={language} car={car} records={records}
          reminders={reminders.filter(r => r.carId === carId)}
          onAdd={() => { setEditing(null); setServiceForm(true); }}
          onEdit={s => { setEditing(s); setServiceForm(true); }} onDelete={deleteService} />}

        {tab === 'cars' && <Cars t={t} language={language} cars={cars} active={carId}
          onAdd={() => setCarForm(true)} onSelect={id => { setCarId(id); setTab('dashboard'); }} onDelete={deleteCar} />}

        {tab === 'history' && <History t={t} language={language} entries={records}
          onEdit={s => { setEditing(s); setServiceForm(true); }} onDelete={deleteService} />}

        {tab === 'settings' && <SettingsPage t={t} onBackup={backup} />}
      </div>

      <Nav tab={tab} onChange={setTab} t={t} />
      {carForm && <CarModal t={t} onClose={() => setCarForm(false)} onSubmit={addCar} />}
      {serviceForm && car && <ServiceModal t={t} car={car} service={editing}
        onClose={() => { setEditing(null); setServiceForm(false); }} onSubmit={saveService} />}
    </main>
  );
}

type TT = (fa: string, en: string) => string;

function Header({ t, car, cars, menu, onMenu, onSelect, onAdd, language, theme, onLanguage, onTheme }:
  { t: TT; car?: CarInfo; cars: CarInfo[]; menu: boolean; onMenu: () => void; onSelect: (id: string) => void;
    onAdd: () => void; language: Language; theme: Theme; onLanguage: () => void; onTheme: () => void }) {
  return (
    <header className="mb-7 flex items-center justify-between gap-3">
      <div className="relative min-w-0">
        <button onClick={onMenu} className="flex min-h-14 max-w-full items-center gap-3 rounded-2xl border border-slate-200 bg-white px-3 text-start shadow-sm dark:border-slate-700 dark:bg-slate-900">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-blue-600 text-white"><Car size={21}/></span>
          <span className="min-w-0">
            <b className="block truncate text-sm">{car ? `${car.make} ${car.model}` : t('بدون خودرو', 'No vehicle')}</b>
            <small className="block truncate text-xs text-slate-500">{car ? `${n(car.year, language)} · ${n(car.mileage, language)} km` : t('خودرو اضافه کنید', 'Add a vehicle')}</small>
          </span>
          <ChevronDown size={18}/>
        </button>
        {menu && <div className="absolute z-20 mt-2 w-72 rounded-2xl bg-white p-2 shadow-2xl dark:bg-slate-900">
          {cars.map(c => <button key={c.id} onClick={() => onSelect(c.id)}
            className="flex w-full items-center gap-3 rounded-xl px-3 py-3 text-start hover:bg-slate-50 dark:hover:bg-slate-800">
            <Car size={16} className="text-blue-600"/>
            <span><b className="block text-sm">{c.make} {c.model}</b><small className="text-xs text-slate-500">{n(c.mileage, language)} km</small></span>
          </button>)}
          <button onClick={onAdd} className="flex w-full items-center gap-2 rounded-xl bg-blue-50 px-3 py-3 text-sm font-bold text-blue-700 dark:bg-blue-950/50">
            <Plus size={18}/>{t('افزودن خودرو', 'Add vehicle')}
          </button>
        </div>}
      </div>
      <div className="flex gap-2">
        <button onClick={onLanguage} className="grid h-11 w-11 place-items-center rounded-xl bg-white text-xs font-black shadow-sm dark:bg-slate-900">{language === 'fa' ? 'EN' : 'فا'}</button>
        <button onClick={onTheme} className="grid h-11 w-11 place-items-center rounded-xl bg-white shadow-sm dark:bg-slate-900">{theme === 'light' ? <Moon size={19}/> : <Sun size={19}/>}</button>
      </div>
    </header>
  );
}

function Dashboard({ t, language, car, records, reminders, onAdd, onEdit, onDelete }:
  { t: TT; language: Language; car?: CarInfo; records: Service[]; reminders: Reminder[];
    onAdd: () => void; onEdit: (s: Service) => void; onDelete: (id: string) => void }) {
  if (!car) return <section className="grid min-h-[60vh] place-items-center text-center"><div>
    <Car size={42} className="mx-auto text-blue-600"/>
    <h1 className="mt-4 text-2xl font-black">{t('اولین خودرو را اضافه کنید', 'Add your first vehicle')}</h1>
  </div></section>;

  const total = records.reduce((a, s) => a + s.cost, 0);
  const upcoming = reminders.map(r => ({ ...r, left: r.dueMileage ? Math.max(0, r.dueMileage - car.mileage) : undefined }))
    .sort((a, b) => (a.left ?? dateScore(a.dueDate)) - (b.left ?? dateScore(b.dueDate)))[0];

  return <section>
    <div className="mb-6"><p className="text-xs font-extrabold tracking-[.12em] text-blue-600">{t('نگهداری هوشمند خودرو', 'SMART VEHICLE CARE')}</p>
      <h1 className="mt-1 text-3xl font-black">{t('همه‌چیز زیر نظر است', 'Everything in check')}</h1></div>

    <article className="mb-6 rounded-[28px] bg-gradient-to-br from-blue-700 to-indigo-800 p-5 text-white shadow-xl">
      <div className="flex justify-between gap-4"><div>
        <span className="inline-flex items-center gap-1 rounded-full bg-white/15 px-3 py-1 text-xs"><BellRing size={14}/>{t('یادآور بعدی', 'UP NEXT')}</span>
        <h2 className="mt-4 text-xl font-black">{upcoming?.title ?? t('یادآور فعالی نیست', 'No active reminder')}</h2>
        <p className="mt-1 text-sm text-blue-100">{upcoming?.left !== undefined
          ? `${n(upcoming.left, language)} ${t('کیلومتر باقی‌مانده', 'km remaining')}`
          : t('برای سرویس بعدی یادآور بسازید.', 'Create a reminder for the next service.')}</p>
      </div><Wrench/></div>
    </article>

    <div className="mb-7 grid grid-cols-2 gap-3 sm:grid-cols-3">
      <Metric icon={<Wrench size={19}/>} label={t('کل سرویس‌ها', 'All services')} value={n(records.length, language)}/>
      <Metric icon={<Gauge size={19}/>} label={t('هزینه کل', 'All-time cost')} value={`${n(total, language)} ${t('تومان', 'IRR')}`}/>
      <Metric icon={<CheckCircle2 size={19}/>} label={t('وضعیت خودرو', 'Health')} value={t('خوب', 'Good')}/>
    </div>

    <ServiceList t={t} language={language} entries={records} onEdit={onEdit} onDelete={onDelete}/>
    <button onClick={onAdd} className="fixed bottom-24 end-5 z-10 flex min-h-14 items-center gap-2 rounded-2xl bg-blue-600 px-5 text-sm font-bold text-white shadow-xl">
      <Plus size={21}/>{t('ثبت سرویس', 'Add service')}
    </button>
  </section>;
}

function Metric({ icon, label, value }: { icon: ReactNode; label: string; value: string }) {
  return <article className="rounded-2xl bg-white p-4 shadow-sm dark:bg-slate-900">
    <span className="grid h-9 w-9 place-items-center rounded-xl bg-blue-50 text-blue-600 dark:bg-blue-950">{icon}</span>
    <p className="mt-3 text-xs font-bold text-slate-500">{label}</p>
    <b className="mt-1 block break-words text-lg font-black">{value}</b>
  </article>;
}

function Cars({ t, language, cars, active, onAdd, onSelect, onDelete }:
  { t: TT; language: Language; cars: CarInfo[]; active: string; onAdd: () => void; onSelect: (id: string) => void; onDelete: (id: string) => void }) {
  return <section>
    <div className="mb-6 flex items-end justify-between"><div>
      <p className="text-xs font-extrabold tracking-[.12em] text-blue-600">{t('گاراژ شما', 'YOUR GARAGE')}</p>
      <h1 className="mt-1 text-3xl font-black">{t('خودروهای من', 'My cars')}</h1>
    </div><button onClick={onAdd} className="grid h-12 w-12 place-items-center rounded-2xl bg-blue-600 text-white"><Plus/></button></div>

    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
      {cars.map(car => <article key={car.id} className={`relative rounded-3xl p-5 ${car.id === active ? 'bg-gradient-to-br from-blue-600 to-indigo-700 text-white' : 'bg-white shadow-sm dark:bg-slate-900'}`}>
        <button onClick={() => onSelect(car.id)} className="block w-full text-start">
          <Car size={25}/><b className="mt-7 block text-xl">{car.make} {car.model}</b>
          <span className="mt-1 block text-sm opacity-75">{n(car.year, language)} · {n(car.mileage, language)} km</span>
          <Plate value={car.plate} inverse={car.id === active}/>
        </button>
        <button onClick={() => onDelete(car.id)} className="absolute end-3 top-3 grid h-10 w-10 place-items-center rounded-xl bg-rose-500/15 text-rose-600 hover:bg-rose-500 hover:text-white"
          aria-label={t('حذف خودرو', 'Delete vehicle')}><Trash2 size={18}/></button>
      </article>)}
    </div>
    {!cars.length && <div className="rounded-3xl border border-dashed p-10 text-center text-slate-500">{t('هنوز خودرویی ندارید.', 'No vehicles added yet.')}</div>}
  </section>;
}

function Plate({ value, inverse }: { value: string; inverse: boolean }) {
  const { first, letter, three, province } = plateParts(value);
  return <div dir="ltr" className={`mt-5 inline-flex select-none items-center overflow-hidden rounded-lg border text-xs font-black ${inverse ? 'border-white/30 bg-white/10 text-white' : 'border-slate-300 bg-slate-50 text-slate-700 dark:border-slate-600 dark:bg-slate-800 dark:text-slate-200'}`}>
    <span className="px-2 py-1.5">{first || '—'}</span>
    <span className="border-x px-2 py-1.5" dir="rtl">{letter || '—'}</span>
    <span className="px-2 py-1.5">{three || '—'}</span>
    <span className="border-r px-2 py-1.5 text-[9px]" dir="rtl">ایران</span>
    <span className="px-2 py-1.5">{province || '—'}</span>
  </div>;
}

function History({ t, language, entries, onEdit, onDelete }:
  { t: TT; language: Language; entries: Service[]; onEdit: (s: Service) => void; onDelete: (id: string) => void }) {
  const [q, setQ] = useState('');
  const visible = entries.filter(s => `${s.title} ${s.shop} ${s.notes}`.toLowerCase().includes(q.toLowerCase()));
  return <section><h1 className="mb-5 text-3xl font-black">{t('سوابق سرویس', 'Service history')}</h1>
    <label className="relative mb-5 block"><Search size={18} className="absolute start-3 top-1/2 -translate-y-1/2 text-slate-400"/>
      <input value={q} onChange={e => setQ(e.target.value)} className="input ps-10" placeholder={t('جست‌وجوی سرویس یا تعمیرگاه', 'Search service or provider')}/></label>
    <ServiceList t={t} language={language} entries={visible} onEdit={onEdit} onDelete={onDelete}/>
  </section>;
}

function ServiceList({ t, language, entries, onEdit, onDelete }:
  { t: TT; language: Language; entries: Service[]; onEdit: (s: Service) => void; onDelete: (id: string) => void }) {
  if (!entries.length) return <div className="rounded-3xl border border-dashed p-9 text-center"><FileText className="mx-auto text-blue-600"/>
    <h3 className="mt-3 font-black">{t('هنوز سرویسی ثبت نشده', 'No services logged yet')}</h3></div>;

  return <section><h2 className="mb-4 text-xl font-black">{t('همه سرویس‌های ثبت‌شده', 'All recorded services')}</h2>
    <div className="space-y-3">{entries.map(s => {
      const c = categories[s.category];
      return <article key={s.id} className="flex gap-3 rounded-2xl bg-white p-4 shadow-sm dark:bg-slate-900">
        <span className={`grid h-11 w-11 shrink-0 place-items-center rounded-xl ${c.color}`}><Wrench size={19}/></span>
        <div className="min-w-0 flex-1"><div className="flex flex-wrap justify-between gap-2"><b>{s.title}</b>
          <span className={`rounded-full px-2 py-1 text-xs font-bold ${c.color}`}>{c[language]}</span></div>
          <p className="mt-1 text-xs text-slate-500">{jalaliDate(s.date, language)} · {n(s.mileage, language)} km</p>
          <p className="mt-2 text-xs text-slate-500">{s.shop || t('بدون تعمیرگاه', 'No provider')} · <b className="text-blue-700 dark:text-blue-300">{n(s.cost, language)} {t('تومان', 'IRR')}</b></p>
          {s.notes && <p className="mt-2 text-sm text-slate-600 dark:text-slate-300">{s.notes}</p>}
        </div>
        <div className="flex flex-col gap-1">
          <button onClick={() => onEdit(s)} className="grid h-10 w-10 place-items-center rounded-xl text-blue-600 hover:bg-blue-50"><Pencil size={17}/></button>
          <button onClick={() => onDelete(s.id)} className="grid h-10 w-10 place-items-center rounded-xl text-rose-600 hover:bg-rose-50"><Trash2 size={17}/></button>
        </div>
      </article>;
    })}</div>
  </section>;
}

function SettingsPage({ t, onBackup }: { t: TT; onBackup: () => void }) {
  return <section><h1 className="mb-6 text-3xl font-black">{t('تنظیمات و خروجی', 'Settings & export')}</h1>
    <button onClick={onBackup} className="flex w-full items-center gap-4 rounded-2xl bg-white p-5 text-start shadow-sm dark:bg-slate-900">
      <Download className="text-blue-600"/><span><b className="block">{t('نسخهٔ پشتیبان اطلاعات', 'Data backup')}</b>
      <small className="text-slate-500">{t('فایل JSON شامل خودروها و سرویس‌ها', 'JSON file including cars and services')}</small></span>
    </button>
    <div className="mt-4 rounded-2xl border border-dashed p-5 text-sm text-slate-500">
      <b className="flex items-center gap-2 text-slate-800 dark:text-white"><Info size={18}/>{t('دربارهٔ برنامه', 'About')}</b>
      <p className="mt-3">{t('طراح و سازنده: یاسر رهنما', 'Designer & developer: Yaser Rahnama')}</p>
    </div>
  </section>;
}

function Nav({ tab, onChange, t }: { tab: Tab; onChange: (v: Tab) => void; t: TT }) {
  const items: [Tab, string, typeof Gauge][] = [
    ['dashboard', t('خانه', 'Home'), Gauge], ['cars', t('خودروها', 'Cars'), Car],
    ['history', t('سوابق', 'History'), FileText], ['settings', t('تنظیمات', 'Settings'), Settings]
  ];
  return <nav className="fixed bottom-0 start-0 z-10 w-full border-t bg-white/95 px-3 pb-[env(safe-area-inset-bottom)] pt-2 backdrop-blur dark:border-slate-800 dark:bg-[#0b1220]/95">
    <div className="mx-auto grid max-w-xl grid-cols-4">{items.map(([id, label, Icon]) =>
      <button key={id} onClick={() => onChange(id)} className={`flex min-h-14 flex-col items-center justify-center gap-1 rounded-xl text-[11px] font-bold ${tab === id ? 'bg-blue-50 text-blue-700 dark:bg-blue-950 dark:text-blue-300' : 'text-slate-500'}`}>
        <Icon size={20}/>{label}
      </button>)}</div>
  </nav>;
}

function Notice({ text, onClose }: { text: string; onClose: () => void }) {
  return <div className="mb-5 flex justify-between rounded-2xl bg-emerald-50 px-4 py-3 text-sm text-emerald-800 dark:bg-emerald-950 dark:text-emerald-200">
    <span>{text}</span><button onClick={onClose}><X size={17}/></button>
  </div>;
}

function CarModal({ t, onClose, onSubmit }: { t: TT; onClose: () => void; onSubmit: (e: FormEvent<HTMLFormElement>) => void }) {
  const [a, setA] = useState(''); const [letter, setLetter] = useState(''); const [b, setB] = useState(''); const [province, setProvince] = useState('');
  const plate = [a, letter, b, province].join('|');

  return <Modal title={t('افزودن خودرو', 'Add vehicle')} subtitle={t('سال تولید بر پایه تقویم هجری شمسی است.', 'Production year uses the Persian calendar.')} onClose={onClose}>
    <form onSubmit={onSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-3"><Field name="make" label={t('برند', 'Make')} required/><Field name="model" label={t('مدل', 'Model')} required/></div>
      <div className="grid grid-cols-2 gap-3"><Field name="year" label={t('سال تولید (شمسی)', 'Production year')} type="number" required min="1300" max={String(currentJalaliYear())}/><Field name="mileage" label={t('کیلومتر فعلی', 'Current km')} type="number" required min="0"/></div>
      <input type="hidden" name="plate" value={plate}/>
      <label className="block text-sm font-bold">{t('شماره پلاک ایران', 'Iranian plate')}
        <div dir="ltr" className="mt-1 grid grid-cols-[.8fr_.7fr_1.1fr_auto_.8fr] items-center gap-1">
          <input required value={a} onChange={e => setA(normalize(e.target.value).replace(/\D/g, '').slice(0,2))} className="input px-1 text-center" inputMode="numeric"/>
          <input required value={letter} onChange={e => setLetter(e.target.value.slice(0,1))} className="input px-1 text-center" dir="rtl"/>
          <input required value={b} onChange={e => setB(normalize(e.target.value).replace(/\D/g, '').slice(0,3))} className="input px-1 text-center" inputMode="numeric"/>
          <span className="grid place-items-center text-[10px] font-black">ایران</span>
          <input required value={province} onChange={e => setProvince(normalize(e.target.value).replace(/\D/g, '').slice(0,2))} className="input px-1 text-center" inputMode="numeric"/>
        </div>
      </label>
      <Field name="fuel" label={t('نوع سوخت', 'Fuel type')} placeholder={t('بنزین', 'Gasoline')}/>
      <button className="primary-button">{t('ذخیره خودرو', 'Save vehicle')}</button>
    </form>
  </Modal>;
}

function ServiceModal({ t, car, service, onClose, onSubmit }:
  { t: TT; car: CarInfo; service: Service | null; onClose: () => void; onSubmit: (e: FormEvent<HTMLFormElement>) => void }) {
  return <Modal title={service ? t('ویرایش سرویس', 'Edit service') : t('ثبت سرویس جدید', 'Log service')}
    subtitle={t('تاریخ را از تقویم هجری شمسی انتخاب کنید.', 'Choose the date from the Persian calendar.')} onClose={onClose}>
    <form onSubmit={onSubmit} className="space-y-4">
      <label className="block text-sm font-bold">{t('دسته‌بندی', 'Category')}
        <select name="category" defaultValue={service?.category ?? 'oil'} className="input mt-1">
          {(Object.keys(categories) as Category[]).map(k => <option key={k} value={k}>{categories[k].fa} / {categories[k].en}</option>)}
        </select>
      </label>
      <Field name="title" label={t('عنوان سرویس', 'Service title')} defaultValue={service?.title}/>
      <div className="grid grid-cols-2 gap-3">
        <JalaliDatePicker name="date" label={t('تاریخ سرویس', 'Service date')} defaultValue={service?.date ?? jalaliToday()} />
        <Field name="mileage" label={t('کیلومتر', 'Mileage')} type="number" required min="0" defaultValue={service?.mileage ?? car.mileage}/>
      </div>
      <Field name="cost" label={t('هزینه (تومان)', 'Cost (IRR)')} type="number" required min="0" defaultValue={service?.cost ?? 0}/>
      <Field name="shop" label={t('تعمیرگاه / ارائه‌دهنده', 'Provider / shop')} defaultValue={service?.shop}/>
      <label className="block text-sm font-bold">{t('یادداشت', 'Notes')}<textarea name="notes" defaultValue={service?.notes} className="input mt-1 min-h-24"/></label>
      <button className="primary-button">{service ? t('ذخیره تغییرات', 'Save changes') : t('ثبت سرویس', 'Save service')}</button>
    </form>
  </Modal>;
}

/* Real Persian-calendar selector: no browser Gregorian date input. */
function JalaliDatePicker({ name, label, defaultValue }: { name: string; label: string; defaultValue: string }) {
  const initial = defaultValue.split('-').map(Number);
  const [year, setYear] = useState(initial[0] || currentJalaliYear());
  const [month, setMonth] = useState(initial[1] || 1);
  const [day, setDay] = useState(initial[2] || 1);

  const maxDay = jalaliMonthDays(year, month);
  const safeDay = Math.min(day, maxDay);
  const value = `${year}-${String(month).padStart(2, '0')}-${String(safeDay).padStart(2, '0')}`;

  return <label className="block text-sm font-bold">
    {label}
    <input type="hidden" name={name} value={value}/>
    <div className="mt-1 grid grid-cols-[1.15fr_.9fr_.9fr] gap-2" dir="rtl">
      <select value={year} onChange={e => setYear(Number(e.target.value))} className="input">
        {Array.from({ length: 81 }, (_, i) => currentJalaliYear() - i).map(y => <option key={y} value={y}>{y}</option>)}
      </select>
      <select value={month} onChange={e => setMonth(Number(e.target.value))} className="input">
        {jalaliMonths.map((m, i) => <option key={m} value={i + 1}>{m}</option>)}
      </select>
      <select value={safeDay} onChange={e => setDay(Number(e.target.value))} className="input">
        {Array.from({ length: maxDay }, (_, i) => i + 1).map(d => <option key={d} value={d}>{d}</option>)}
      </select>
    </div>
    <small className="mt-1 block text-emerald-600">✓ {value.replace(/\d/g, d => '۰۱۲۳۴۵۶۷۸۹'[Number(d)])}</small>
  </label>;
}

function Field({ name, label, type = 'text', required, defaultValue, placeholder, min, max }:
  { name: string; label: string; type?: string; required?: boolean; defaultValue?: string | number; placeholder?: string; min?: string; max?: string }) {
  return <label className="block text-sm font-bold">{label}
    <input name={name} type={type} required={required} defaultValue={defaultValue} placeholder={placeholder} min={min} max={max} className="input mt-1"/>
  </label>;
}

function Modal({ title, subtitle, children, onClose }: { title: string; subtitle: string; children: ReactNode; onClose: () => void }) {
  return <div className="fixed inset-0 z-30 grid place-items-end bg-slate-950/45 sm:place-items-center sm:p-5">
    <div className="max-h-[92dvh] w-full max-w-lg overflow-y-auto rounded-t-[28px] bg-white p-5 dark:bg-slate-900 sm:rounded-[28px]">
      <div className="mb-5 flex justify-between gap-3"><div><h2 className="text-xl font-black">{title}</h2><p className="mt-1 text-sm text-slate-500">{subtitle}</p></div>
        <button onClick={onClose} className="grid h-10 w-10 place-items-center rounded-xl bg-slate-100 dark:bg-slate-800"><X size={20}/></button></div>
      {children}
    </div>
  </div>;
}
