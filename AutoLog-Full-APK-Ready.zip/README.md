# AutoLog Professional

نسخه‌ی آماده‌ی توسعه‌ی AutoLog با React + Vite + Tailwind + Capacitor.

## امکانات موجود
- فارسی / انگلیسی
- حالت روشن / تاریک
- چند خودرو
- پلاک ایران با ترتیب صحیح
- تقویم هجری شمسی برای ثبت سرویس
- سوابق سرویس
- حذف خودرو و سوابق وابسته
- پشتیبان JSON
- آماده برای بسته‌بندی Android با Capacitor

## اجرای وب
```bash
npm install
npm run dev
```

## آماده‌سازی Android
```bash
npm install
npm run android:init
npm run android:sync
npm run android:open
```

سپس در Android Studio می‌توان APK خروجی گرفت.
