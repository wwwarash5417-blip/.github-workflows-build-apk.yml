import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.autolog.app',
  appName: 'AutoLog',
  webDir: 'dist',
  bundledWebRuntime: false
};

export default config;
